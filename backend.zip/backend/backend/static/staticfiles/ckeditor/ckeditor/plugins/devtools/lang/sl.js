﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","sl",{title:"Podatki elementa",dialogName:"Ime pogovornega okna",tabName:"Ime zavihka",elementId:"ID elementa",elementType:"Tip elementa"});